# Speech_Recognition

###### This repository has .py file for speech recognition. If we use the particualr code then it will take input from microphone and will print what ever we are saying in English.,
